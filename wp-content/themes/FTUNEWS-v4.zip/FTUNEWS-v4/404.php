<?php
/**
 * @package WordPress
 * @subpackage HTML5_Boilerplate
 */

//get_header(); ?>

<div style="max-width: 600px; margin:0px auto">
  <img src="<?php echo get_template_directory_uri() ?>/images/404.jpg" draggable="false" style="width:100%; height:auto">
</div>

<?php //get_footer(); ?>