<?php if ( !defined('ABSPATH') ) exit; // Shhh ?>
<div class="updated"><p><?php _e('Logs has been reset!', TP_TD); ?></p></div>