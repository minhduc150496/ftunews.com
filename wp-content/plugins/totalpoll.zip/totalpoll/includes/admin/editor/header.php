<?php if ( !defined('ABSPATH') ) exit; // Shhh  ?>
<!-- .tp-wrapper -->
<div id="tp-wrapper" class="tp-wrapper">
    <div style="display: none;"><?php wp_editor('', 'totalpoll'); ?></div>
    <?php do_tp_action('tp_admin_editor_header'); ?>