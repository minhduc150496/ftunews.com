<?php

/**
 * TotalPoll Uninstallation.
 * Note: Not ready yet.
 */